package com.example.smartpolchat;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.*;
import android.view.View;
import org.json.*;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private EditText editTextInput;
    private Button buttonSend;
    private RecyclerView chatRecyclerView;
    private ChatAdapter chatAdapter;
    private final List<ChatMessage> chatList = new ArrayList<>();
    private final HashMap<String, RuleEntry> ruleMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getSupportActionBar() != null) getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        editTextInput = findViewById(R.id.editTextInput);
        buttonSend = findViewById(R.id.buttonSend);
        chatRecyclerView = findViewById(R.id.chatRecyclerView);

        loadRulesFromJson();

        chatAdapter = new ChatAdapter(chatList, this);
        chatRecyclerView.setAdapter(chatAdapter);
        chatRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        buttonSend.setOnClickListener(v -> {
            String input = editTextInput.getText().toString().trim();
            if (input.isEmpty()) return;

            // 유저 메시지 추가
            chatList.add(new ChatMessage(ChatMessage.TYPE_USER, input, getCurrentTime()));
            chatAdapter.notifyItemInserted(chatList.size() - 1);
            chatRecyclerView.scrollToPosition(chatList.size() - 1);
            editTextInput.setText("");

            // 규정 응답 처리
            if (ruleMap.containsKey(input)) {
                RuleEntry entry = ruleMap.get(input);

                // 텍스트 응답 추가
                chatList.add(new ChatMessage(ChatMessage.TYPE_BOT, entry.answerText, getCurrentTime()));

                // 버튼 응답 추가
                if (entry.buttons != null && !entry.buttons.isEmpty()) {
                    chatList.add(new ChatMessage(ChatMessage.TYPE_BUTTON, null, getCurrentTime(), entry.buttons));
                }

                chatAdapter.notifyItemRangeInserted(chatList.size() - 2, 2);
                chatRecyclerView.scrollToPosition(chatList.size() - 1);
                return;
            }

            // 기본 응답
            chatList.add(new ChatMessage(ChatMessage.TYPE_BOT, "🤖 답변 준비 중...", getCurrentTime()));
            chatAdapter.notifyItemInserted(chatList.size() - 1);
            chatRecyclerView.scrollToPosition(chatList.size() - 1);
        });
    }

    private void loadRulesFromJson() {
        try {
            InputStream is = getAssets().open("rules.json");
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            JSONArray arr = new JSONArray(new String(buffer, "UTF-8"));

            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                RuleEntry entry = new RuleEntry();
                entry.answerText = obj.getString("answerText");

                // 키워드 배열 처리
                String keywordField = obj.getString("keyword");
                entry.keywords = keywordField.split("\\s*,\\s*");

                // 버튼 리스트 처리
                JSONArray buttonsArray = obj.optJSONArray("buttons");
                if (buttonsArray != null) {
                    List<RuleEntry.ButtonEntry> buttonList = new ArrayList<>();
                    for (int j = 0; j < buttonsArray.length(); j++) {
                        JSONObject btnObj = buttonsArray.getJSONObject(j);
                        RuleEntry.ButtonEntry btn = new RuleEntry.ButtonEntry();
                        btn.label = btnObj.getString("label");
                        btn.image = btnObj.getString("image");
                        buttonList.add(btn);
                    }
                    entry.buttons = buttonList;
                }

                // 키워드 맵핑
                for (String key : entry.keywords) {
                    ruleMap.put(key.trim(), entry);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("a h:mm", Locale.getDefault());
        return sdf.format(new Date());
    }
}